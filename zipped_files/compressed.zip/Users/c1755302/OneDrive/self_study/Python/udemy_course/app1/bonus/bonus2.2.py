# An app to count to 6

x = 1

while x <= 6:
    print(x)
    x = x + 1