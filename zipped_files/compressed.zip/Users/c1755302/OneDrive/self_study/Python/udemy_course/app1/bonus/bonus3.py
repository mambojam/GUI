meals = ['pasta', 'pizza', 'salad']

for meal in meals:
    print(meal.capitalize())

print("Bye!")